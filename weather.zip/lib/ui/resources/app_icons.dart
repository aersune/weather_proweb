abstract class AppIcons {
  static const humidity = 'assets/icons/humidity.svg';
  static const location = 'assets/icons/location.svg';
  static const menu = 'assets/icons/menu.svg';
  static const wind = 'assets/icons/wind.svg';
  static const fells = 'assets/icons/feels.svg';
  static const sunset = 'assets/icons/sunset.svg';
  static const sunrise = 'assets/icons/sunrise.svg';
}