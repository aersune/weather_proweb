abstract class AppBg{
  static const shinyDay = 'assets/images/shiny_day.png';
  static const shinyNight = 'assets/images/rainy_night.png';
  static const cloudyDay = 'assets/images/cloudy_day.png';
  static const cloudyNight = 'assets/images/cloudy_night.png';
  static const rainyDay = 'assets/images/rainy_day.png';
  static const rainyNight = 'assets/images/rainy_night.png';
  static const snowDay = 'assets/images/snow_day.png';
  static const snowNight = 'assets/images/snow_night.png';
  static const fogDay = 'assets/images/fog_day.png';
  static const fogNight = 'assets/images/fog_night.png';

}