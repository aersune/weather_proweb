

class HiveBox {
  static const String favoriteBox = 'favorite_box';
}